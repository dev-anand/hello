 Code downloaded from html-form-guide.com
 This code may be used and distributed freely without any charge.
 
 The file send-email-form.php contains the PHP code and the 
 form code explained in the tutorial.
 
 Uploading the form:
 1. Open send-email-form.php in a text editor and 
    Update the email address and the file upload folder
 You can customize the form code as required
 
 2. Make the file upload folder writable
 
 
 Disclaimer
 ----------
 This file is provided "as is" with no expressed or implied warranty.
 The author accepts no liability if it causes any damage whatsoever.